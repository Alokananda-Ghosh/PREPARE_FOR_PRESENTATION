package com.cg.bankaccount.testing;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.bankaccount.service.IBankService;
import com.cg.bankaccount.service.IBankServiceImpl;

import junit.framework.Assert;

public class NameValidationTesting {

	IBankService obj=new IBankServiceImpl();
	/*@Test
	public void test() {
		fail("Not yet implemented");
	}
*/

	@Test
	public void testNameStartingWithCapital()
	{
		String name="Alokananda";
		Assert.assertEquals(true, obj.validateName(name));
	}
	@Test
	public void testNameStartingWithLowerCase()
	{
		String name="alokananda";
		Assert.assertFalse("Enter valid name", obj.validateName(name));
	}
	@Test
	public void testNameWithallUpperCase()
	{
		String name="ALOKANANDA";
		Assert.assertEquals(true,obj.validateName(name));
	}
	@Test
	public void testNameWithNumAsCharacter()
	{
		String name="ALOKANANDA97";
		Assert.assertFalse("Enter valid name", obj.validateName(name));
	}
	@Test
	public void testNameStartingWithallLowerCase()
	{
		String name="aLOKANANDA";
		Assert.assertFalse("Enter valid name", obj.validateName(name));
	}
	@Test
	public void testNameNull()
	{
		String name="null";
		Assert.assertFalse("Enter valid name", obj.validateName(name));
	}
	@Test
	public void testNameBlank()
	{
		String name="";
		Assert.assertFalse("Enter valid name", obj.validateName(name));
	}
}

