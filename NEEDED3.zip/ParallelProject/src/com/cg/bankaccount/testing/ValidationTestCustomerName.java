package com.cg.bankaccount.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.bankaccount.bean.Account;

import junit.framework.Assert;

class ValidationTestCustomerName {
	Account account=new Account();
	@Test
	public void testNameStartingWithCapital()
	{
		String name="Alokananda";
		account.setName(name);
		Assert.assertEquals("Alokananda",account.getName());
	}
	@Test
	public void testNameStartingWithLowerCase()
	{
		String name="alokananda";
		account.setName(name);
		Assert.assertEquals("alokananda", account.getName());
	}
	@Test
	public void testNameWithNumAsCharacter()
	{
		String name="ALOKANANDA89";
		account.setName(name);
		Assert.assertEquals("ALOKANANDA89",account.getName());
	}
	

}
