package com.cg.bankaccount.testing;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class DisplayAccount {

/*	@Test
	public void test() {
		fail("Not yet implemented");
	}*/
	@Ignore("It will display account details on console only")
	public void displaytest()
	{
		
	}

}