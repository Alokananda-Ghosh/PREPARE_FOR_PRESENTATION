package com.cg.bankaccount.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.bankacccount.exceptions.InvalidDepositException;
import com.cg.bankacccount.exceptions.InvalidFundAmountException;
import com.cg.bankacccount.exceptions.InvalidWithdrawException;
import com.cg.bankaccount.service.IBankService;
import com.cg.bankaccount.service.IBankServiceImpl;

public class AccountMain {
	public static void main(String[] args) {
		IBankService service = new IBankServiceImpl(); // creating object of IBankService
		Scanner sc = new Scanner(System.in);// creating Scanner class object to input user data
		while (true) {
			System.out.println("1.Choose 1 to Create Account");
			System.out.println("2.Choose 2 to show balance");
			System.out.println("3.Choose 3 to deposit into account");
			System.out.println("4.Choose 4 to withdraw from account");
			System.out.println("5.Choose 5 to fund transfer");
			System.out.println("6.Choose 6 to display account");
			System.out.println("7.Choose 7 to exit");
			int choose = sc.nextInt();
			switch (choose) {
			case 1:
				long accno = ((int) (Math.random() * 100)); // generating account no randomly
				String name;
				do {
					System.out.println("Please enter your name:");
					name = sc.next();
				} while (!service.validateName(name)); // checking validation method for name

				long phoneno;
				do {
					System.out.println("Please enter your phone number:");
					phoneno = sc.nextLong();
				} while (!service.validateContactNumber(phoneno)); // checking validation method for contact number

				double balance = 0;
				service.createAccount(accno, name, phoneno, balance);
				break;

			case 2:
				System.out.println("Enter account number to show balance:");
				long accountnumber = sc.nextLong();
				System.out.println("Balance :" + service.showBalance(accountnumber));
				break;

			case 3:
				System.out.println("Enter account number where the deposit take place");
				long accountnumber2 = sc.nextLong();
				System.out.println("Enter amount you want to deposit:");
				double deposit = sc.nextDouble();

				try {
					service.deposit(accountnumber2, deposit);
				} catch (InvalidDepositException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 4:
				System.out.println("Enter the acount number from where the withdrawn take place");
				long accountnumber3 = sc.nextLong();
				System.out.println("Enter the amount you want to withdraw");
				double withdraw = sc.nextDouble();

				try {
					service.withdraw(accountnumber3, withdraw);
				} catch (InvalidWithdrawException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 5:
				System.out.println("Enter the account number from where the money to be transfered");
				long acoountnumber4 = sc.nextLong();

				System.out.println("Enter the account number to where the money to be transfered");
				long acoountnumber5 = sc.nextLong();
				System.out.println("Enter the amount to be transfered");
				double fundamt = sc.nextDouble();

				try {
					service.fundtransfer(acoountnumber4, acoountnumber5, fundamt);
				} catch (InvalidFundAmountException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 6:
				service.display();
				break;

			case 7:
				System.out.println("terminated!!");
				System.exit(0); // to exit system
				sc.close(); // closing resource
			default:
				System.out.println("Please choose valid option!");

			}
		}
	}
}
