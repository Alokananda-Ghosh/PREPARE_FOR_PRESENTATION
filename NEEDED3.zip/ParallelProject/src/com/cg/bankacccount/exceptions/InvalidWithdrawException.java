package com.cg.bankacccount.exceptions;

public class InvalidWithdrawException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public InvalidWithdrawException(String msg)
{
	super(msg);
}
}

