package com.cg.bankaccount.service;

import java.sql.SQLException;

import com.cg.bankaccount.bean.Account;
import com.cg.bankaccount.bean.Transaction;
import com.cg.bankaccount.dao.IBankAccountDao;
import com.cg.bankaccount.dao.IBankAccountDaoImpl;
import com.cg.bankaccount.exceptions.BankExceptions;

public class IBankAccountServiceImpl implements IBankAccountService
{
	
    IBankAccountDao dao=new IBankAccountDaoImpl();

	@Override
	public void createAccount(long AccNo, String Name, Double balance) throws BankExceptions {
		// TODO Auto-generated method stub
		dao.createAccount(AccNo, Name, balance);
	}

	@Override
	public void showBalance(long AccNo) throws BankExceptions {
		// TODO Auto-generated method stub
		dao.showBalance(AccNo);
	}

	@Override
	public void deposit(long AccNo, double deposit) throws BankExceptions {
		// TODO Auto-generated method stub
		dao.deposit(AccNo, deposit);
	}

	@Override
	public void withdraw(long AccNo, double withdraw) throws BankExceptions {
		// TODO Auto-generated method stub
		dao.withdraw(AccNo, withdraw);
	}

	@Override
	public void fundtransfer(long AccNo1, long AccNo2, double fundamt) throws BankExceptions {
		// TODO Auto-generated method stub
		dao.fundtransfer(AccNo1, AccNo2, fundamt);
	}



	@Override
	public Account display() throws BankExceptions {
		// TODO Auto-generated method stub
		return dao.display();
	}

	@Override
	public Transaction display1() throws BankExceptions {
		// TODO Auto-generated method stub
		return dao.display1();
	}

	@Override
	public boolean validateAccNo(long AccNo) {
		// TODO Auto-generated method stub
       String number=String.valueOf(AccNo);
		
		String regex1="^[0-9]{6}$";
		//long number=Long.parseLong(regex1);
		if(number.matches(regex1))
		{
		return true;
		}
		return false;
	}
	
}



