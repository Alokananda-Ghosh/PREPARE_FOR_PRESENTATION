package com.cg.bankaccount.ui;

import com.cg.bankaccount.bean.*;
import java.sql.SQLException;

import java.util.Scanner;

import com.cg.bankaccount.exceptions.BankExceptions;
import com.cg.bankaccount.service.IBankAccountService;
import com.cg.bankaccount.service.IBankAccountServiceImpl;

public class AccountMain {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		IBankAccountService service = new IBankAccountServiceImpl();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("1.Choose 1 to Create Account");
			System.out.println("2.Choose 2 to show balance");
			System.out.println("3.Choose 3 to deposit into account");
			System.out.println("4.Choose 4 to withdraw from account");
			System.out.println("5.Choose 5 to fund transfer");
			System.out.println("6.Choose 6 to display account");
			System.out.println("7.display transaction");
			System.out.println("8.Choose 8 to exit");
			int choose = sc.nextInt();
			switch (choose) {
			case 1:
				long accno;
				do {
					System.out.println("Enter account number");
					accno = sc.nextLong();
				} while (!service.validateAccNo(accno));

				System.out.println("Please enter your name:");
				String name = sc.next();
				System.out.println("Enter balance");
				double balance = sc.nextDouble();

				try {
					service.createAccount(accno, name, balance);
				} catch (BankExceptions e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 2:
				System.out.println("Enter account number to show balance:");
				long accno1 = sc.nextLong();
				try {
					service.showBalance(accno1);
				} catch (BankExceptions e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				System.out.println("Enter amount you want to deposit:");
				double deposit = sc.nextDouble();
				System.out.println("Enter account number where the deposit take place");
				long accno2 = sc.nextLong();
				try {
					service.deposit(accno2, deposit);
				} catch (BankExceptions e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:
				System.out.println("Enter the amount you want to withdraw");
				double withdraw = sc.nextDouble();
				System.out.println("Enter the acount number from where the withdrawn take place");
				long accno5 = sc.nextLong();
				try {
					service.deposit(accno5, withdraw);
				} catch (BankExceptions e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 5:
				System.out.println("Enter the account number from where the money to be transfered");
				long accno3 = sc.nextLong();
				System.out.println("Enter the account number to where the money to be transfered");
				long accno4 = sc.nextLong();
				System.out.println("Enter the amount to be transfered");
				double fundamt = sc.nextDouble();

				try {
					service.fundtransfer(accno3, accno4, fundamt);
				} catch (BankExceptions e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 6:
				try {
					Account acc = service.display();

					System.out.println(acc);
				} catch (BankExceptions e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 7:
				try {
					Transaction tran = service.display1();

					System.out.println(tran);
				} catch (BankExceptions e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 8:
				System.out.println("terminated!");
				System.exit(0); // to exit system
				sc.close(); // closing resource
			default:
				System.out.println("Enter valid choice!");

			}
		}
	}

}
