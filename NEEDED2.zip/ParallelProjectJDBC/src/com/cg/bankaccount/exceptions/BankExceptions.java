package com.cg.bankaccount.exceptions;

public class BankExceptions extends Exception
	{


		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public BankExceptions(String message)
		{
			super(message);
		}
	}

