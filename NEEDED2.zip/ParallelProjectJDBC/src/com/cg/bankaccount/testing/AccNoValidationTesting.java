package com.cg.bankaccount.testing;

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.bankaccount.service.IBankAccountService;
import com.cg.bankaccount.service.IBankAccountServiceImpl;

import junit.framework.Assert;

class AccNoValidationTesting {

	IBankAccountService obj=new IBankAccountServiceImpl();
	/*@Test
	void test() {
		fail("Not yet implemented");
	}
*/
	@Test
	public void testAccountNumber()
	{
		long AccNo=123456;
		assertTrue(obj.validateAccNo(AccNo));
	}
	@Test
	public void testAccountNumberForLengthLessThanSix()
	{
		long AccNo=12345;
		assertFalse("enter valid account number",obj.validateAccNo(AccNo));
	}
}
