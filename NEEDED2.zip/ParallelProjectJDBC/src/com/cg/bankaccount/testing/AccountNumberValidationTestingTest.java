package com.cg.bankaccount.testing;





import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.cg.bankaccount.bean.Account;

class AccountNumberValidationTestingTest {

	Account acc=new Account();
	/*@Test
	void test() {
		fail("Not yet implemented");
	}*/
	@Test
	public void testAccountNumber()
	{
		long AccNo=123456;
		acc.setAccNo(AccNo);
	Assert.assertEquals(AccNo,acc.getAccNo(),1);
	}
	@Test
	public void testAccountNumberForLengthLessThanSix()
	{
		long AccNo=12345;
		
		acc.setAccNo(AccNo);
		Assert.assertEquals(12345L,acc.getAccNo(),1);
	}
}
