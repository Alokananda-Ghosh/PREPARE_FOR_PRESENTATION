package com.cg.bankaccount.dao;

public class QueryMapping {
	static final String INSERT_QUERY="insert into Account1 values(?,?,?)";
	static final String NAME_QUERY="select * from Account1 where Name=?";
	static final String GETBALANCE_QUERY="select balance from Account1 where AccNo=?";
	static final String QUERY="select * from Account1 where AccNo=?";
	static final String UPDATE_QUERY="update Account1 set balance=? where AccNo=?";
	static final String INSERTTRANSACTION_QUERY="insert into Transaction values(?,?,?,?)";
	static final String  DISPLAYACCOUNT_QUERY="select * from Account1 ";
	static final String  DISPLAYTRANSACTION_QUERY="select * from Transaction ";
	
}
